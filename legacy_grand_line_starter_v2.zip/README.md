# One Piece: Legacy of the Grand Line — First Prototype

This is the first playable milestone for the larger game concept.

## Included in this prototype
- 3D third-person island exploration
- Multiple island regions and a harbor
- Player movement, jumping, sprinting, and camera controls
- Enemies, basic combat, and a special area attack
- Quest-giver, merchant, navigator, treasure chests
- Coins, health potions, inventory, leveling, and map
- Touch controls for phones and tablets

## Run it
Open `index.html` in a modern browser with an internet connection. The 3D engine is loaded from a CDN.

## Next development milestones
1. Character select and original-character customization
2. Better combat animations, enemy AI, boss encounters
3. Real ship steering, sailing, and naval combat
4. Branching story missions and faction choice
5. Expanded island interiors, NPC routines, and events
6. Save/load progression and settings
7. Multiplayer architecture (a separate, substantial project)

This is a prototype, not a finished game. Official One Piece characters, designs, names, and assets require appropriate rights for a public commercial release.
